$(document).ready(function() {
  $('#creditsbutton').click(function(){

    window.location.href = 'popup.html';

  });
});
